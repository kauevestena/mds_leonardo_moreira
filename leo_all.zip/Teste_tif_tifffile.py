import tifffile

imagem_tiff = tifffile.imread('pegasus_1m.tif')