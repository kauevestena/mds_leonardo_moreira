import cv2

img = cv2.imread('filled_pegasus_1m_x100.tiff')